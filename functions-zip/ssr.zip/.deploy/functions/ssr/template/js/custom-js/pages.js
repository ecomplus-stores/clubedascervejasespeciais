// Add your custom JavaScript for storefront pages here.
window.ecomCart.on('addItem', ({ data, item }) => { window.location.href = '/app/#/cart' })
